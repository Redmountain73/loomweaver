# scripts/validate_program.py
# Validate Program + Modules (+ optional Capabilities) using LOCAL, REF-FREE schemas.
# Tonight’s pragmatics:
#  - Accept outline-style shorthands and normalize them before validating:
#       inputs/outputs: "name (Text)"  -> {"name":"name","resultType":"Text"}
#       examples: "some text"          -> {"description":"some text"}
#  - Load CANONICAL module schema, overlay {successCriteria, examples} + relax name pattern (spaces).
#  - Embed the module schema inside a synthetic Program schema at #/$defs/Module.
#  - No network; warnings by default; --strict -> nonzero on any error.

from __future__ import annotations
import argparse, json, re, sys
from pathlib import Path
from typing import Any, Dict, List

try:
    import jsonschema
    from jsonschema import Draft202012Validator
except Exception:
    jsonschema = None
    Draft202012Validator = None  # type: ignore

ROOT = Path(__file__).resolve().parents[1]
SCHEMAS = ROOT / "Schemas"

SUCCESS_CRITERIA_PROP = {
    "type": "array",
    "items": {"type": "string"},
    "default": []
}
EXAMPLES_PROP = {
    "type": "array",
    "items": {
        "type": "object",
        "required": ["description"],
        "properties": {
            "description": {"type": "string"},
            "input": {"type": "object"},
            "output": {}
        },
        "additionalProperties": False
    },
    "default": []
}

_SHORTHAND_RE = re.compile(r"^\s*([A-Za-z_][A-Za-z0-9_\-]*)\s*\(\s*([^)]+?)\s*\)\s*$")

def load_json(p: Path) -> dict:
    return json.loads(p.read_text(encoding="utf-8"))

def _scrub_ids(node: Any) -> Any:
    """Remove all '$id' keys to prevent any external resolution."""
    if isinstance(node, dict):
        return {k: _scrub_ids(v) for k, v in node.items() if k != "$id"}
    if isinstance(node, list):
        return [_scrub_ids(v) for v in node]
    return node

def _rewrite_internal_refs_to_embedded(node: Any) -> Any:
    """
    Inside the MODULE schema only:
      Turn "$ref": "#/something"  --> "$ref": "#/$defs/Module/something"
    """
    if isinstance(node, dict):
        out = {}
        for k, v in node.items():
            if k == "$ref" and isinstance(v, str) and v.startswith("#/"):
                out[k] = "#/$defs/Module" + v[1:]
            else:
                out[k] = _rewrite_internal_refs_to_embedded(v)
        return out
    if isinstance(node, list):
        return [_rewrite_internal_refs_to_embedded(v) for v in node]
    return node

def load_module_schema_with_overlay() -> dict:
    """
    Start from CANONICAL schema (Schemas/loom-module.schema.json).
    - Overlay successCriteria/examples (non-breaking)
    - RELAX name.pattern to allow spaces for current outlines
    - Strip $id and rewrite internal refs for embedded use
    """
    mod = load_json(SCHEMAS / "loom-module.schema.json")

    props = mod.setdefault("properties", {})
    props.setdefault("successCriteria", SUCCESS_CRITERIA_PROP)
    props.setdefault("examples", EXAMPLES_PROP)

    # relax name pattern to allow a space character (keeps forbidden-word guard)
    name_prop = props.get("name")
    if isinstance(name_prop, dict):
        pat = name_prop.get("pattern")
        if isinstance(pat, str):
            name_prop["pattern"] = (
                pat.replace("[A-Za-z0-9_\\-]{0,127}", "[A-Za-z0-9_\\- ]{0,127}")
                   .replace("[A-Za-z0-9_\\\\-]{0,127}", "[A-Za-z0-9_\\\\- ]{0,127}")
            )

    mod = _scrub_ids(mod)
    mod = _rewrite_internal_refs_to_embedded(mod)
    return mod

def synth_program_schema_with_embedded_module(module_schema: dict) -> dict:
    """Program schema that embeds the module schema at #/$defs/Module and references it."""
    return {
        "title": "Loom Program (local, embedded module schema)",
        "type": "object",
        "required": ["type", "name", "purposeAndIdentity", "modules", "version", "astVersion"],
        "additionalProperties": False,
        "properties": {
            "type": {"const": "Program"},
            "name": {"type": "string"},
            "purposeAndIdentity": {"type": "array", "items": {"type": "string"}},
            "modules": {
                "type": "array",
                "minItems": 1,
                "items": {"$ref": "#/$defs/Module"}
            },
            "version": {"type": "string", "pattern": r"^\d+\.\d+$"},
            "astVersion": {
                "type": "string",
                "pattern": r"^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)(?:-[0-9A-Za-z-.]+)?(?:\+[0-9A-Za-z-.]+)?$"
            }
        },
        "$defs": {
            "Module": module_schema
        }
    }

def _coerce_io_list(items: Any) -> List[Dict[str, Any]]:
    """
    Accept either:
      - list of objects {name, resultType}
      - list of strings "name (Type)"  -> {"name": name, "resultType": Type}
    """
    out: List[Dict[str, Any]] = []
    if not isinstance(items, list):
        return out
    for it in items:
        if isinstance(it, dict):
            out.append(it)
            continue
        if isinstance(it, str):
            m = _SHORTHAND_RE.match(it)
            if m:
                out.append({"name": m.group(1), "resultType": m.group(2)})
            else:
                # best-effort fallback
                out.append({"name": it.strip(), "resultType": "Any"})
    return out

def _normalize_combined_instance(combined: dict) -> dict:
    """
    Normalize outline-ish fields so the instance matches the schema:
      - inputs/outputs shorthand -> objects
      - examples strings -> objects with description
    """
    mods = combined.get("modules") or []
    for m in mods:
        if isinstance(m, dict):
            if "inputs" in m:
                m["inputs"] = _coerce_io_list(m.get("inputs"))
            if "outputs" in m:
                m["outputs"] = _coerce_io_list(m.get("outputs"))
            if "examples" in m and isinstance(m["examples"], list):
                m["examples"] = [
                    (x if isinstance(x, dict) else {"description": str(x)})
                    for x in m["examples"]
                ]
    combined["modules"] = mods
    return combined

def main(argv=None) -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--program", required=True, help="agents/<agent>.program.json")
    ap.add_argument("--modules", required=True, help="agents/<agent>.modules.ast.json")
    ap.add_argument("--capabilities", required=False, help="agents/<agent>.capabilities.json")
    ap.add_argument("--strict", action="store_true", help="exit nonzero on any validation error")
    args = ap.parse_args(argv)

    errors: list[str] = []

    # Load inputs
    try:
        program  = load_json(Path(args.program))
        modules  = load_json(Path(args.modules))
        caps     = load_json(Path(args.capabilities)) if args.capabilities and Path(args.capabilities).exists() else None
    except Exception as e:
        print(f"Failed to read input JSON: {e}")
        return 2

    # Combine and normalize
    combined = dict(program)
    combined["modules"] = modules.get("modules") or []
    combined = _normalize_combined_instance(combined)

    # Cheap guards
    if not combined.get("name"):
        errors.append("Program.name missing")
    if not combined.get("modules"):
        errors.append("Program.modules empty (combined)")

    if jsonschema is None or Draft202012Validator is None:
        print("[warn] jsonschema not installed; run: pip install jsonschema")
    else:
        # Prepare schemas locally
        try:
            module_schema = load_module_schema_with_overlay()
        except FileNotFoundError as e:
            errors.append(f"Schema file missing: {e}")
            module_schema = None  # type: ignore

        if module_schema is not None:
            prog_schema = synth_program_schema_with_embedded_module(module_schema)

            try:
                Draft202012Validator(schema=prog_schema).validate(combined)
            except Exception as e:
                errors.append(f"Program schema validation: {e}")

        # Capabilities (optional)
        if caps is not None:
            try:
                cap_schema = load_json(SCHEMAS / "loom-capabilities.schema.json")
                Draft202012Validator(schema=cap_schema).validate(caps)
            except FileNotFoundError:
                errors.append("Capabilities schema file missing: Schemas/loom-capabilities.schema.json")
            except Exception as e:
                errors.append(f"Capabilities schema validation: {e}")

    # Report
    if errors:
        print("VALIDATION: WARNINGS/ERRORS")
        for e in errors:
            print(" -", e)
        if args.strict:
            return 1
    else:
        print("VALIDATION: OK")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
