# scripts/loom_cli.py
# Tiny DX wrapper: compile, validate, run, test (routes to existing scripts).
import argparse, os, sys, subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
AGENTS = ROOT / "agents" / "loomweaver"

def run_py(args_list):
    proc = subprocess.run([sys.executable] + args_list, cwd=ROOT)
    return proc.returncode

def main():
    ap = argparse.ArgumentParser(prog="loom")
    sub = ap.add_subparsers(dest="cmd", required=True)

    p_compile = sub.add_parser("compile")
    p_compile.add_argument("--outline", default=str(AGENTS / "loomweaver.outline.md"))
    p_compile.add_argument("--out", default=str(AGENTS / "loomweaver.program.json"))

    p_validate = sub.add_parser("validate")
    p_validate.add_argument("--strict", action="store_true")

    p_run = sub.add_parser("run")
    p_run.add_argument("--module", required=True)
    p_run.add_argument("--kv", nargs="*", default=[])

    p_test = sub.add_parser("test")
    p_test.add_argument("--strict", action="store_true")

    args = ap.parse_args()

    if args.cmd == "compile":
        return run_py(["-m", "compile_outline_to_program", args.outline, args.out])

    if args.cmd == "validate":
        return run_py([
            str(ROOT / "scripts" / "validate_program.py"),
            "--program",    str(AGENTS / "loomweaver.program.json"),
            "--modules",    str(AGENTS / "loomweaver.modules.ast.json"),
            "--capabilities", str(AGENTS / "loomweaver.capabilities.json"),
            *(["--strict"] if args.strict else [])
        ])

    if args.cmd == "run":
        kvs = args.kv
        return run_py([
            str(ROOT / "scripts" / "run_ast_module.py"),
            str(AGENTS / "loomweaver.modules.ast.json"),
            args.module, *kvs
        ])

    if args.cmd == "test":
        return run_py([
            str(ROOT / "scripts" / "run_module_tests.py"),
            "--modules", str(AGENTS / "loomweaver.modules.ast.json"),
            "--tests",   str(AGENTS / "loomweaver.tests.json"),
            *(["--strict"] if args.strict else [])
        ])

if __name__ == "__main__":
    raise SystemExit(main())
