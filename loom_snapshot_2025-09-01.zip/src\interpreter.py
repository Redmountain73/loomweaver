# src/interpreter.py
from __future__ import annotations
from typing import Any, Dict, List, Tuple, Optional
from pathlib import Path
from .ast_builder import build_ast
from .tokenizer import tokenize
from .parser import parse

class RuntimeErrorLoom(Exception): pass

# ------------------------- expression evaluator -------------------------

class Evaluator:
    def __init__(self, env: Dict[str, Any]):
        self.env = env

    def eval(self, node: Optional[Dict[str, Any]]) -> Any:
        if node is None: return None
        t = node.get("type")
        if t in ("Number", "String", "Boolean"):
            return node.get("value")
        if t == "Identifier":
            name = node.get("name")
            if name in self.env:
                return self.env[name]
            raise RuntimeErrorLoom(f"Undefined identifier: {name}")
        if t == "Unary":
            op = node.get("op")
            v = self.eval(node.get("expr"))
            if op == "-": return -v
            if op in ("+",): return v
            if op == "not":
                if not isinstance(v, bool):
                    raise RuntimeErrorLoom("not expects boolean")
                return (not v)
            raise RuntimeErrorLoom(f"unknown unary op: {op}")
        if t == "Binary":
            op = node.get("op")
            if op == "and":
                l = self.eval(node.get("left"))
                if not isinstance(l, bool):
                    raise RuntimeErrorLoom("and expects booleans")
                if not l: return False
                r = self.eval(node.get("right"))
                if not isinstance(r, bool):
                    raise RuntimeErrorLoom("and expects booleans")
                return l and r
            if op == "or":
                l = self.eval(node.get("left"))
                if not isinstance(l, bool):
                    raise RuntimeErrorLoom("or expects booleans")
                if l: return True
                r = self.eval(node.get("right"))
                if not isinstance(r, bool):
                    raise RuntimeErrorLoom("or expects booleans")
                return l or r

            l = self.eval(node.get("left")); r = self.eval(node.get("right"))
            if op == "+": return l + r
            if op == "-": return l - r
            if op == "*": return l * r
            if op == "/": return l / r
            if op == "==": return l == r
            if op == "!=": return l != r
            if op == "<": return l < r
            if op == "<=": return l <= r
            if op == ">": return l > r
            if op == ">=": return l >= r
            raise RuntimeErrorLoom(f"unknown binary op: {op}")

        return node  # e.g., Range handled in statements

def _expr_to_text(node: Any) -> str:
    try:
        if isinstance(node, dict):
            t = node.get("type")
            if t == "Boolean": return "true" if bool(node.get("value")) else "false"
            if t == "Number": return str(node.get("value"))
            if t == "String":
                v = node.get("value")
                return repr(v) if v is not None else '""'
            if t == "Identifier": return str(node.get("name") or "")
            return t or ""
        if isinstance(node, bool): return "true" if node else "false"
        if isinstance(node, (int, float)): return str(node)
        if isinstance(node, str): return repr(node)
    except Exception:
        pass
    return ""

class Interpreter:
    def __init__(self, registry: Optional[Dict[str, Dict[str, Any]]] = None):
        self.env: Dict[str, Any] = {}
        self.evaluator = Evaluator(self.env)
        self.registry = registry or {}
        self.receipt: Dict[str, Any] = {
            "engine": "interpreter",
            "logs": [],
            "ask": [],
            "callGraph": [],
            "steps": [],
            "env": {},
        }
        self._call_stack: List[str] = []

    @staticmethod
    def _get_expr(args: Dict[str, Any], *keys: str) -> Optional[Dict[str, Any]]:
        for k in keys:
            v = args.get(k)
            if v is not None: return v
        return None

    def _extract_flow(self, module: Dict[str, Any]) -> List[Dict[str, Any]]:
        return module.get("flow") or module.get("steps") or module.get("block", {}).get("steps") or []

    def exec_step(self, step: Dict[str, Any], step_index: int = 0) -> Tuple[Any, bool]:
        verb = step.get("verb")
        args = step.get("args", {}) or {}

        if verb == "Show":
            expr = self._get_expr(args, "expr", "text", "value")
            val = self.evaluator.eval(expr) if isinstance(expr, dict) else (expr if expr is not None else "")
            self.receipt["logs"].append(str(val))
            print(val)
            return None, False

        if verb == "Return":
            expr = self._get_expr(args, "expr", "value")
            val = self.evaluator.eval(expr) if isinstance(expr, dict) else expr
            return val, True

        if verb == "Ask":
            name = args.get("name")
            default_expr = args.get("default")
            if name not in self.env:
                self.env[name] = self.evaluator.eval(default_expr) if default_expr is not None else None
            self.receipt["ask"].append({"name": name})
            return None, False

        if verb == "Make":
            name = args.get("name") or args.get("var") or args.get("identifier")
            expr = self._get_expr(args, "expr", "value", "to")
            if not name:
                raise RuntimeErrorLoom("Make requires a name")
            self.env[name] = self.evaluator.eval(expr) if expr is not None else None
            self.receipt["steps"].append({"verb": "Make", "envDelta": {name: self.env[name]}})
            return None, False

        if verb == "Forget":
            name = args.get("name")
            existed = name in self.env
            self.env.pop(name, None)
            self.receipt["steps"].append({"verb": "Forget", "name": name, "existed": existed})
            return None, False

        if verb == "Check":
            return None, False

        if verb == "Choose":
            branches = args.get("branches", []) or []
            for idx, br in enumerate(branches):
                if br.get("otherwise"):
                    continue
                when_expr = br.get("when")
                ok = bool(self.evaluator.eval(when_expr))
                self.receipt["steps"].append({
                    "event": "choose",
                    "predicateTrace": [{"expr": _expr_to_text(when_expr), "value": ok}],
                    "selected": None,
                })
                if ok:
                    self.receipt["steps"][-1]["selected"] = {"branch": idx, "kind": "when"}
                    body = br.get("steps") or br.get("block") or br.get("body") or []
                    if isinstance(body, dict):
                        body = body.get("steps") or []
                    for st in body:
                        res, returned = self.exec_step(st)
                        if returned:
                            return res, True
                    return None, False
            for idx, br in enumerate(branches):
                if br.get("otherwise"):
                    body = br.get("steps") or br.get("block") or br.get("body") or []
                    if isinstance(body, dict):
                        body = body.get("steps") or []
                    for st in body:
                        res, returned = self.exec_step(st)
                        if returned:
                            self.receipt["steps"].append({
                                "event": "choose",
                                "predicateTrace": [],
                                "selected": {"branch": idx, "kind": "otherwise"},
                            })
                            return res, True
                    self.receipt["steps"].append({
                        "event": "choose",
                        "predicateTrace": [],
                        "selected": {"branch": idx, "kind": "otherwise"},
                    })
                    return None, False
            return None, False

        if verb == "Repeat":
            iterator = args.get("iterator")
            it_name = None
            if isinstance(iterator, dict) and "name" in iterator:
                it_name = iterator["name"]
            elif isinstance(iterator, str):
                it_name = iterator
            if not it_name:
                it_name = args.get("iter")

            iterable_expr = args.get("iterable")
            if iterable_expr is None:
                iterable_expr = args.get("range")
            if iterable_expr is None or not it_name:
                raise RuntimeErrorLoom("Malformed Repeat: missing iterator/iterable")

            if isinstance(iterable_expr, dict) and iterable_expr.get("type") == "Range":
                start = int(self.evaluator.eval(iterable_expr.get("start")))
                end = int(self.evaluator.eval(iterable_expr.get("end")))
                inclusive = bool(iterable_expr.get("inclusive", True))  # DEFAULT INCLUSIVE
                stepv = 1 if end >= start else -1
                values = list(range(start, end + (1 if inclusive else 0), stepv))
            else:
                values = self.evaluator.eval(iterable_expr)

            if values is None:
                values = []
            if not isinstance(values, list):
                raise RuntimeErrorLoom("Repeat iterable must be a list or range")

            body_steps: List[Dict[str, Any]] = step.get("steps")
            if not isinstance(body_steps, list):
                blk = step.get("block") or step.get("body")
                if isinstance(blk, list):
                    body_steps = blk
                elif isinstance(blk, dict):
                    body_steps = blk.get("steps") or []
                else:
                    body_steps = []

            for v in values:
                self.env[it_name] = v
                for st in body_steps:
                    res, returned = self.exec_step(st)
                    if returned:
                        return res, True

            self.receipt["steps"].append({"verb": "Repeat", "iter": it_name, "count": len(values)})
            return None, False

        if verb == "Call":
            mod_name = args.get("module")
            inputs_obj = args.get("inputs") or {}
            child_inputs: Dict[str, Any] = {}
            for k, ex in inputs_obj.items():
                child_inputs[k] = self.evaluator.eval(ex)

            if mod_name in self.registry:
                callee = self.registry[mod_name]
            else:
                mod_file = Path("Modules") / f"{mod_name}.loom"
                if not mod_file.exists():
                    raise RuntimeErrorLoom(f"Call: cannot resolve module {mod_name}")
                text = mod_file.read_text(encoding="utf-8")
                callee = build_ast(parse(tokenize(text)))

            child = Interpreter(registry=self.registry)
            child_result = child.run(callee, inputs=child_inputs)

            inputsResolved: Dict[str, Dict[str, Any]] = {}
            asked = [a.get("name") for a in child.receipt.get("ask", []) if isinstance(a, dict)]
            for key in set(asked) | set(child_inputs.keys()):
                if key in child_inputs:
                    inputsResolved[key] = {"source": "explicit", "value": child_inputs[key]}
                else:
                    inputsResolved[key] = {"source": "default", "value": child.env.get(key)}

            self.receipt["steps"].append({
                "event": "call",
                "module": mod_name,
                "inputs": dict(child_inputs),
                "inputsResolved": inputsResolved,
            })
            caller = self._call_stack[-1] if self._call_stack else "<anonymous>"
            self.receipt["callGraph"].append({"from": caller, "to": mod_name, "atStep": step_index})

            save_as = args.get("result") or args.get("saveAs") or args.get("save") or args.get("as")
            if save_as:
                self.env[save_as] = child_result

            return None, False

        raise RuntimeErrorLoom(f"Unknown verb: {verb}")

    def exec_block(self, block: Dict[str, Any]) -> Any:
        result = None
        for idx, step in enumerate(block.get("steps", [])):
            res, returned = self.exec_step(step, step_index=idx)
            if returned:
                result = res
                break
        return result

    def run(self, module: Dict[str, Any], inputs: Optional[Dict[str, Any]] = None) -> Any:
        if inputs:
            self.env.update(inputs)
        name = module.get("name") or module.get("module", {}).get("name") or "<anonymous>"
        self._call_stack.append(name)
        try:
            flow = self._extract_flow(module)
            result = self.exec_block({"steps": flow})
            return result
        finally:
            self._call_stack.pop()
            self.receipt["env"] = dict(self.env)

def _load_or_build_module(path: str) -> Dict[str, Any]:
    p = Path(path)
    text = p.read_text(encoding="utf-8")
    return build_ast(parse(tokenize(text)))

def run_module_from_file(path: str, inputs: Optional[Dict[str, Any]] = None) -> Tuple[Any, Dict[str, Any]]:
    module = _load_or_build_module(path)
    interp = Interpreter()
    result = interp.run(module, inputs=inputs or {})
    return result, interp.receipt

def run_tests_from_file(path: str) -> Tuple[int, int, List[Any]]:
    module = _load_or_build_module(path)
    tests = module.get("tests") or []
    passed, results = 0, []
    from .expr import parse_expr
    def coerce_scalar(v: Any) -> Any:
        if isinstance(v, (int, float, bool)): return v
        if isinstance(v, str):
            s = v.strip().rstrip(".")
            try:
                node = parse_expr(s)
                return Evaluator({}).eval(node)
            except Exception:
                if (s.startswith('"') and s.endswith('"')) or (s.startswith("'") and s.endswith("'")):
                    return s[1:-1]
                return s
        return v
    def coerce_inputs(d: Dict[str, Any]) -> Dict[str, Any]:
        return {k: coerce_scalar(v) for k, v in (d or {}).items()}
    for t in tests:
        name = t.get("name") or "test"
        expected = coerce_scalar(t.get("expected"))
        inputs = coerce_inputs(t.get("inputs") or t.get("input") or {})
        actual = Interpreter().run(module, inputs=inputs)
        ok = (actual == expected)
        if ok: passed += 1
        results.append((name, ok, actual, expected))
    return passed, len(tests), results
