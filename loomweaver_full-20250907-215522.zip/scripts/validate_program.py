# scripts/validate_program.py
# Validate Program+Modules+Capabilities. Warnings by default; --strict -> nonzero exit on any error.

import argparse, json, os, sys
from pathlib import Path

try:
    import jsonschema
except Exception:
    jsonschema = None

ROOT = Path(__file__).resolve().parents[1]

def load_json(p: Path):
    return json.loads(p.read_text(encoding="utf-8"))

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--program", required=True, help="path to agents/<agent>.program.json")
    ap.add_argument("--modules", required=True, help="path to agents/<agent>.modules.ast.json")
    ap.add_argument("--capabilities", required=False, help="path to agents/<agent>.capabilities.json")
    ap.add_argument("--strict", action="store_true", help="exit nonzero on validation error(s)")
    args = ap.parse_args()

    errors = []

    # Load inputs
    program = load_json(Path(args.program))
    modules_ast = load_json(Path(args.modules))
    caps = load_json(Path(args.capabilities)) if args.capabilities and Path(args.capabilities).exists() else None

    # Assemble a combined program for schema validation (program header + modules list)
    combined = dict(program)
    combined["modules"] = modules_ast.get("modules") or []

    # Basic structural checks
    if not combined.get("name"):
        errors.append("Program.name missing")
    if not combined.get("modules"):
        errors.append("Program.modules empty (combined)")

    # jsonschema validation if available
    if jsonschema:
        try:
            prog_schema = load_json(ROOT / "Schemas" / "loom-program.schema.json")
            module_schema_ref = (ROOT / "Schemas" / "loom-module.schema.json").resolve().as_uri()
            # ensure $ref in program schema can see module schema via resolver
            resolver = jsonschema.RefResolver(base_uri=module_schema_ref, referrer=prog_schema)
            jsonschema.validate(instance=combined, schema=prog_schema, resolver=resolver)
        except Exception as e:
            errors.append(f"Program schema validation: {e}")

        if caps is not None:
            try:
                cap_schema = load_json(ROOT / "Schemas" / "loom-capabilities.schema.json")
                jsonschema.validate(instance=caps, schema=cap_schema)
            except Exception as e:
                errors.append(f"Capabilities schema validation: {e}")
    else:
        print("[warn] jsonschema not installed; run: pip install jsonschema")

    if errors:
        print("VALIDATION: WARNINGS/ERRORS")
        for e in errors:
            print(" -", e)
        if args.strict:
            sys.exit(1)
    else:
        print("VALIDATION: OK")

if __name__ == "__main__":
    main()
